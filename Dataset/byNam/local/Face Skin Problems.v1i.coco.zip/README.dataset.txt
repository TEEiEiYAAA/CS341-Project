# Face Skin Problems > 2024-01-27 11:49pm
https://universe.roboflow.com/dental-caries-mlx7r/face-skin-problems

Provided by a Roboflow user
License: CC BY 4.0

