import kaggle
import boto3
import os
from io import BytesIO
import zipfile
from kaggle.api.kaggle_api_extended import KaggleApi

api = KaggleApi()
api.authenticate()

os.environ['KAGGLE_CONFIG_DIR'] = '/tmp/.kaggle'

# ตั้งค่าของ AWS S3
s3 = boto3.client('s3', region_name='us-east-1')  # เปลี่ยน Region ตามที่ต้องการ
bucket_name = 'kaggle-dataset-skincare'
s3_folder = 'data/'  # ชื่อโฟลเดอร์ใน S3

# ตั้งค่าของ Kaggle API
dataset_name = "dominoweir/skincare-product-ingredients"

def lambda_handler(event, context):
    # ดาวน์โหลดข้อมูลจาก Kaggle ไปยัง memory
    kaggle.api.dataset_download_files(dataset_name, path='/tmp', unzip=True)

    # วนลูปเพื่ออัปโหลดไฟล์ทั้งหมดในโฟลเดอร์ที่ดาวน์โหลดมาไปยัง S3
    for root, dirs, files in os.walk('/tmp'):
        for file in files:
            local_file_path = os.path.join(root, file)
            s3_file_path = os.path.join(s3_folder, file)

            # อัปโหลดไฟล์ไปยัง S3
            with open(local_file_path, 'rb') as data:
                s3.upload_fileobj(data, bucket_name, s3_file_path)

            print(f"Uploaded {file} to s3://{bucket_name}/{s3_file_path}")

    return {
        'statusCode': 200,
        'body': f"Successfully uploaded files to s3://{bucket_name}/{s3_folder}"
    }
